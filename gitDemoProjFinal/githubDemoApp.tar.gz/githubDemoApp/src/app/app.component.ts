/*
* app.component is a simple shell that hosts those sub-components.
* @Author : Argusoft
*/

import {Component} from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {}
